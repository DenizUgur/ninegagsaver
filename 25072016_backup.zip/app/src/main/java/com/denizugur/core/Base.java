package com.denizugur.core;

import android.support.annotation.NonNull;

public final class Base {

    @NonNull
    public static final String SUPPORT_EMAIL = "ninegagsaver@gmail.com";

}
